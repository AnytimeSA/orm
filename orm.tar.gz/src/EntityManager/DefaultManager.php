<?php

namespace Anytime\ORM\EntityManager;

class DefaultManager extends Manager
{
}
