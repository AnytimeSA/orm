<?php

namespace Anytime\ORM\EntityManager;

class DefaultEntityRepository extends EntityRepository
{
}
